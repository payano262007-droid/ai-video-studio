# AI Video Studio

Aplicación personal de generación de vídeo con IA para **web, Android e iOS**, construida con Expo (React Native) y un backend Node.js.

## Incluye
- Interfaz adaptable a móvil y navegador.
- Generación desde texto e imagen.
- Selección de formato y duración.
- Estado de generación y galería local de resultados.
- Backend separado para mantener la clave del proveedor fuera de la app.

## Requisitos
- Node.js 20+
- Una cuenta y API key de [fal.ai](https://fal.ai/)
- Para Android/iOS: Expo Go o compilación con EAS.

## Arranque

### 1. Backend
```bash
cd server
cp .env.example .env
# Edita .env y añade FAL_KEY y, si procede, FAL_TEXT_MODEL / FAL_IMAGE_MODEL
npm install
npm run dev
```

### 2. App
En otra terminal:
```bash
cd app
cp .env.example .env
# Define EXPO_PUBLIC_API_URL: http://localhost:8787 para web local.
# En móvil físico usa la IP local de tu ordenador, por ejemplo http://192.168.1.20:8787
npm install
npx expo start
```
Pulsa `w` para web o escanea el QR con Expo Go.

## Configurar el proveedor
El servidor usa la API de cola de fal.ai. Modelos por defecto:
- Texto a vídeo: `fal-ai/wan-t2v`
- Imagen a vídeo: `fal-ai/wan-i2v`

Puedes cambiarlos en `server/.env`. Los modelos, campos admitidos, duración, costes y límites pueden cambiar según el proveedor; comprueba la ficha del modelo en fal.ai. La clave **solo** debe estar en `server/.env`, nunca en variables `EXPO_PUBLIC_*`.

## Importante
Este proyecto es un punto de partida funcional de interfaz y backend. La generación real necesita una API key válida, un modelo disponible y saldo/créditos en el proveedor. No incluye alojamiento ni publicación automática en las tiendas.
